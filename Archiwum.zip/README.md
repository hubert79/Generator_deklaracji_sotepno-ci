# Generator_deklaracji_sotepno-ci

Narzędzie do generowania kodu HTML tagów zgodnych z WCAG2.1 na strony spełniające warunki dostępności.
